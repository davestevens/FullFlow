#ifndef INCLUDE_TYPEDEFS_H
#define INCLUDE_TYPEDEFS_H

typedef struct sobel sobel;
typedef struct i_sobel i_sobel;
typedef struct i_sobel_req i_sobel_req;
typedef struct i_sink i_sink;
typedef struct i_sink_req i_sink_req;
typedef struct Source Source;
typedef struct Sob Sob;
typedef struct Sink Sink;
typedef struct TOP TOP;
typedef struct Proc Proc;
typedef struct autogen_fork_class autogen_fork_class;
typedef struct autogen_join_class autogen_join_class;

#endif
