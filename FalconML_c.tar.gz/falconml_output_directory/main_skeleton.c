/*
** THIS FILE COULD BE OVERWRITTEN!
** SAVE IT WITH A DIFFERENT NAME BEFORE RERUNNING FALCONMLCGEN!
** main() skeleton - edit before use.
*/
#include <stdlib.h>
#include "falconml_c_eventq.h"
#include "falconml_c_stubskel.h"
#include "TOP__software.h"
/* Define the required port classes. */

static volatile int initialized = 0;

/*
** The main event processing loop for all threads.
*/
static int MainEventLoop(int tid) {
	while(!initialized); /* Wait until the initialization by the initialization thread is completed. */
	deassert_reset(tid); /* Trigger initialization of all state machines processed by this thread. */
	/*
	** Place your stimulus code within this loop.
	*/
	while(1) {
		handle(tid); /* Handle the least recent event for this thread in the global event queue. */
	}
	return 1;
}
/*
** Exactly one thread also does the initialization before entering the main event processing loop.
*/
static int InitializeAndRunThread(int tid) {
	/* Allocate an instance of the top-level class. */
	struct TOP__software top;
	/* Allocate instances of the required port classes and pointers to the provided port classes. */
	/* Instantiate the input and output primitive/flow ports. */
	/* Construct the instance of the top-level class. */
	falconml__initialise_event_queue(); /* Initialize the global event queue for the events */
	construct_TOP__software(&top, 0x40000000);
	/* Call constructors for the example class objects. */
	/* Bind port(s) with the example class objects. */
	/* Connect the input and output primitive/flow ports. */
	initialized = 1; /* Allow all threads (including this one) to begin their event loops. */
	return MainEventLoop(tid);
}

/*
** All other threads simply drop straight into the main event processing loop.
*/
static int RunThread(int tid) {
	return MainEventLoop(tid);
}
/*
** Check if NUM_EVENT_QUEUES is defined.
*/
#ifndef NUM_EVENT_QUEUES
#	error NUM_EVENT_QUEUES is undefined. Use -DNUM_EVENT_QUEUES=value to define number of different contexts
#endif

/*
** All threads start, in parallel, here.
*/
int main() {
	const int cpuid = getCPUID(NULL) >> 8;
	return (cpuid ? RunThread : InitializeAndRunThread)(cpuid);
}
