# Product definition for Class
# Bound variables:
#   PRODUCT  the product being build
#   ELT      the element to generate  

import act
from java.util import ArrayList

if (ELT.isStereotyped("CxxProject") or ELT.isStereotyped("CxxCodeGeneration")):
  subelements = ArrayList()

  for manifestation in ELT.getUtilized():
    manifestedElement = manifestation.getUtilizedElement()
    subelements.add(manifestedElement)
  
  PRODUCT.addSubElements(subelements)
