# Product definition for Class
# Bound variables:
#   PRODUCT  the product being build
#   ELT      the element to generate 

import act
from java.util import ArrayList

if (CXX.isCxxElement(ELT) and not act.isNoCode(ELT)):
  # headerFile = CXX.makeNamespacePath(ELT) + "/" + CXX.makeCxxName(ELT) + "." + CXX.makeHeaderFileExtension(ELT)
  headerFile = CXX.makeDefaultHeaderFilePath(ELT)

  # bodyFile = CXX.makeNamespacePath(ELT) + "/" + CXX.makeCxxName(ELT) + "." + CXX.makeBodyFileExtension(ELT)
  bodyFile   = CXX.makeDefaultBodyFilePath(ELT)

  files = ArrayList()

  if (act.isExternal(ELT)):
    if (ELT.isTagged ("Cxx.GenerateHeaderFile")):
      files.add(headerFile)  
  else:
    files.add(headerFile)
    files.add(bodyFile)
  
  PRODUCT.addFilesGeneration(ELT, files, "ClassGen")       
