#
# Template PackageGen
# Binded variables
#   CXX      facilities for Cxx specific production and navigation
#   GEN      facilities for code production
#   MDL      facilities for model navigation and condition testing
#   ENG      ACT ENG (used to call another template))
#
################################################################################
# Local utilities functions 
#    naming rules:
#       - if the utility function directly prints out the generated code it must be named printXXXXX  
#         where XXXX is expected to summarize the function role
#       - if the utility function return a piece of generated code as a string it must be name makeXXXXXX 
#         where XXXX is expected to summarize the function role
#       - if the utility function is used to get some elements of the model and return a list of model elements (navigation convinience)
#         it must be named modelGetXXXXX where XXXX is expected to summarize the function role
#    other rules:
#       - any utility function takes a model element as first parameter (name it el)
#       - utility function must not define global variables of their own
#
from com.modeliosoft.modelio.cxxdesigner.engine.act import IAct
from com.modeliosoft.modelio.api.model import ObUtils
from com.modeliosoft.modelio.api import *
from com.modeliosoft.modelio.api.model.uml.infrastructure import *
from com.modeliosoft.modelio.api.model.uml.statik import *
import act

class PackageGen(IAct):
  def printBodyBottomNotes(self, out, el):
    bodyBottom = GEN.getModifiableNotes(el, "Cxx.Body.Bottom")
    if len(bodyBottom) > 0:
      for s in bodyBottom:
        out.println(s)
      out.println()
    
  def printBodyTopNotes(self, out, el):
    topBottom = GEN.getModifiableNotes(el, "Cxx.Body.Top")
    if len(topBottom) > 0:
      for s in topBottom:
        out.println(s)
      out.println()
          
  def printIncludeNotes(self, out, el):
    useBody = GEN.getModifiableNotes(el, "Cxx.Use.Body")
    if len(useBody) > 0:
      for s in useBody:
        out.println(s)
      out.println()
    
  def printBodyNamespaceMemberNotes(self, out, el):
    bodyNamespaceMembers = GEN.getModifiableNotes(el, "Cxx.Body.NamespaceMember")
    if len(bodyNamespaceMembers) > 0:
      for s in bodyNamespaceMembers:
        out.println(s)
      out.println()
        
  def printInstanceInit(self, out, el):
    if el.cardDeclared() > 0:
      out.println("// instances initialization")
      for instance in el.getDeclared():
        if not act.isNoCode(instance):
          out.println(ENG.evalAct("InstanceGenCxx", instance))
      out.println()
  
  def printUseIncludes(self, out, el):
    bodyUseIncludes = CXX.getBodyUseIncludes(el)
    if len(bodyUseIncludes) > 0:
      for s in bodyUseIncludes:
        out.printf("#include <%s>\n", [s])
      out.println()

  def printLibIncludes(self, out, el):
    libIncludes = CXX.getLibIncludes(el)
    if len(libIncludes) > 0:
      out.println("//includes for used library types")
      for s in libIncludes:
        out.printf("#include <%s>\n", [s])
      out.println()
  
  def printAutoIncludes(self, out, el):
    autoIncludes = CXX.getAutoIncludes(el)
    if len(autoIncludes) > 0:
      out.println("//automatic includes")
      for s in autoIncludes:
        out.printf("#include <%s>\n", [s])
      out.println()
  
  def printElementImportsIncludes(self, out, el):
    for dt in act.getDataTypes(el):
      for s in CXX.getHeaderUseIncludes(dt):
        out.printf("#include <%s>\n", [s])
    for s in CXX.getHeaderUseIncludes(el):
      out.printf("#include <%s>\n", [s])
    out.println()
  
  def printOpenNamespace(self, out, el):
    # Open parent namespaces
    for ns in CXX.getNamespacePackages(el):
      out.printf("namespace %s {\n", [CXX.makeCxxName(ns)])

    # Open current namespace      
    if (not ObUtils.isTagged(el, "Cxx.Package.NoNamespace")):
      out.printf("namespace %s {\n", [CXX.makeCxxName(el)])
      
  def printCloseNamespace(self, out, el):
    # Close current namespace
    if (not ObUtils.isTagged(el, "Cxx.Package.NoNamespace")):
      out.printf("} // namespace %s\n", [CXX.makeCxxName(el)])

    # Close parent namespaces
    parentNamespaces = CXX.getNamespacePackages(el)
    parentNamespaces.reverse()
    for ns in parentNamespaces:
      out.printf("} // namespace %s\n", [CXX.makeCxxName(ns)])
  
  def printPublicIncludes(self, out, el):
    if (ObUtils.isTagged(el, "Cxx.Package.GenInterface")):
      out.println("//forwards for public package members")
  
      for child in el.getOwnedElement(IClass):
        if (child.getVisibility() == Public):
          printClass(self, child)
          out.println(CXX.makeCxxName(child) + " ;\t// " + child.getMetaclassName() + " " + child.getName())
      
      for child in el.getOwnedElement(IInterface):
        if (child.getVisibility() == Public):
          printClass(child)
          out.println(CXX.makeCxxName(child) + " ;\t// " + child.getMetaclassName() + " " + child.getName())
  
  def printClass(self, out, el):
    if (ObUtils.isTagged(el, "Cxx.Struct")):
      out.println("struct")
    else:
      out.println("class")
  
  def printHeaderTopNotes(self, out, el):
    headerTop = GEN.getModifiableNotes(el, "Cxx.Header.Top")
    if len(headerTop) > 0:
      for s in headerTop:
        out.println(s)
      out.println()

  def printUseHeaderNotes(self, out, el):
    useHeader = GEN.getModifiableNotes(el, "Cxx.Use.Header") 
    if len(useHeader) > 0:
      for s in useHeader:
        out.println(s)
      out.println()
  
  def printHeaderBottomNotes(self, out, el):
    headerBottom = GEN.getModifiableNotes(el, "Cxx.Header.Bottom")
    if len(headerBottom) > 0:
      for s in headerBottom:
        out.println(s)
      out.println()

  def printHeaderNamespaceMemberNotes(self, out, el):
    headerNamespaceMember = GEN.getModifiableNotes(el, "Cxx.Header.NamespaceMember")
    if len(headerNamespaceMember) > 0:
      for s in headerNamespaceMember:
        out.println(s)
      out.println()
  
  def printDataTypesHeaderTopNotes(self, out, el):
    for dt in act.getDataTypes(el):
      for s in GEN.getModifiableNotes(dt, "Cxx.Header.Top"):
        out.println(s)
      out.println()
  
  def printDataTypesHeaderBottomNotes(self, out, el):
    for dt in act.getDataTypes(el):
      for s in GEN.getModifiableNotes(dt, "Cxx.Header.Bottom"):
        out.println(s)
      out.println()
  
  def printPackageEnums(self, out, el):
    if el.cardOwnedElement(IEnumeration) > 0:
      out.println("//enumerations")
      for enum in el.getOwnedElement(IEnumeration):
        out.println(ENG.evalAct("EnumerationGen", enum))
      out.println()
  
  def printPackageTypedefs(self, out, el):
    if el.cardOwnedElement(IDataType) > 0:
      out.println("//typedefs")
      for enum in el.getOwnedElement(IDataType):
        out.println(ENG.evalAct("TypeDefGen", enum))
      out.println()
  
  def printAliasingDeclaration(self, out, el):
    tags = ObUtils.getTagValues(el, "Cxx.Package.Alias")
    if not tags is None:
      for tag in tags:
        out.println("namespace " + tag + " = " + CXX.makeCxxName(el));

  def makeValidCxxId(self, el):
    id = el.getIdentifier();
    id = id.replace("-", "_");
  
    return id;
  
  def makeHeaderGuardDefine(self, el):
    return "__" + CXX.makeCxxName(el) + "_" + self.makeValidCxxId(el) + "_H_INCLUDED"

################################################################################
# Generation code
#

  def run(self, ctx, pkg):
    cxx = ctx.getOutputs()[1]
    hxx = ctx.getOutputs()[0]
    
    elName = pkg.getName();
    
    # Cxx generation
    if not cxx is None:
      if not act.isExternal(pkg):
        cxx.println(act.makeCopyright(pkg))
        
        cxx.println("/*")
        cxx.println("* File type : package body")
        cxx.printf("* Package   : %s\n", [elName])
        cxx.println()
        cxx.println("*/")
      
        cxx.println("//package header file")
        cxx.printf("#include \"%s\"\n", [CXX.makeHeaderFilename(pkg)])
        self.printUseIncludes(cxx, pkg)
        for dataType in pkg.getOwnedElement(IDataType):
          self.printUseIncludes(cxx, dataType)
          self.printBodyTopNotes(cxx, dataType)
      
        self.printBodyTopNotes(cxx, pkg)
        
        if not ObUtils.isTagged(pkg, "Cxx.Package.NoNamespace"):
          self.printOpenNamespace(cxx, pkg)
      
        self.printInstanceInit(cxx, pkg)
        self.printBodyNamespaceMemberNotes(cxx, pkg)
      
        if not ObUtils.isTagged(pkg, "Cxx.Package.NoNamespace"):
          self.printCloseNamespace(cxx, pkg)
        
        for dataType in pkg.getOwnedElement(IDataType):
          self.printBodyTopNotes(cxx, dataType)
          
        self.printBodyBottomNotes(cxx, pkg)
    

    headerGuardDefine = self.makeHeaderGuardDefine(pkg)
    
    # Hxx generation
    
    hxx.println(act.makeCopyright(pkg))
    
    hxx.printf("#ifndef %s\n", [headerGuardDefine])
    hxx.printf("#define %s\n", [headerGuardDefine])
    hxx.println("/*")
    hxx.println("* File type : package header")
    hxx.printf("* Package   : %s\n",  [elName])
    hxx.println("*/")
    
    if act.isExternal(pkg):
      hxx.println(GEN.getExternalContents(pkg))
    else:
      self.printLibIncludes(hxx, pkg)
      self.printAutoIncludes(hxx, pkg)
      self.printElementImportsIncludes(hxx, pkg)
      
      hxx.println(ENG.evalAct("ForwardDeclsOtherNamespaces", pkg))
      
      parent = pkg.getCompositionOwner()
      
      if (not parent is None and not(act.isAtRoot(parent)) and parent.getMetaclassName() == "Package"):
        ownerPackage = CXX.makeHeaderFilename(parent)
        if (len (ownerPackage) > 0):
          hxx.println("//owner package header file")        
          hxx.printf("#include \"%s\"", [ownerPackage])
      hxx.println()
    
      self.printHeaderTopNotes(hxx, pkg)
      self.printUseHeaderNotes(hxx, pkg)
      self.printDataTypesHeaderTopNotes(hxx, pkg)
      
      if act.hasDocumentation(pkg):
        hxx.println(act.makeDocumentationComment(pkg))
      
      self.printOpenNamespace(hxx, pkg)
      
      hxx.println(ENG.evalAct("ForwardDeclsNamespace", pkg))
    
      self.printHeaderNamespaceMemberNotes (hxx, pkg)
    
      self.printPackageEnums(hxx, pkg)
      hxx.println(ENG.evalAct("PackageInstances", pkg))
      self.printPackageTypedefs(hxx, pkg)
              
      self.printPublicIncludes (hxx, pkg)
      
      self.printCloseNamespace(hxx, pkg)
    
      self.printAliasingDeclaration(hxx, pkg)
    
      self.printDataTypesHeaderBottomNotes (hxx, pkg)
      self.printHeaderBottomNotes(hxx, pkg)

    hxx.printf("#endif // %s\n", [headerGuardDefine])
