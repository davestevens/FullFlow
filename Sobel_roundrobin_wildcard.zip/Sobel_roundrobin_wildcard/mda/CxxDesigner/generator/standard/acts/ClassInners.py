#
# Template ClassInners
# Binded variables
#   CXX      facilities for Cxx specific production and navigation
#   GEN      facilities for code production
#   MDL      facilities for model navigation and condition testing
#   ENG      ACT ENG (used to call another template))
#
################################################################################
# Local utilities functions 
#    naming rules:
#       - if the utility function directly prints out the generated code it must be named printXXXXX  
#         where XXXX is expected to summarize the function role
#       - if the utility function return a piece of generated code as a string it must be name makeXXXXXX 
#         where XXXX is expected to summarize the function role
#       - if the utility function is used to get some elements of the model and return a list of model elements (navigation convinience)
#         it must be named modelGetXXXXX where XXXX is expected to summarize the function role
#    other rules:
#       - any utility function takes a model element as first parameter (name it el)
#       - utility function must not define global variables of their own
#
from com.modeliosoft.modelio.cxxdesigner.engine.act import IAct
from com.modeliosoft.modelio.api import *
from com.modeliosoft.modelio.api.model.uml.infrastructure import *
from com.modeliosoft.modelio.api.model.uml.statik import * 
from com.modeliosoft.modelio.api.model import ObUtils
from java.util import ArrayList
import act

class ClassInners (IAct):

################################################################################
# Generation code
#
  def run(self, ctx, el):
    out = ctx.getOutputs()[0]
    publicClasses = ArrayList()
    protectedClasses = ArrayList()
    privateClasses = ArrayList()
  
    # Sort all inner classes
    for theClass in el.getOwnedElement():
      if not act.isNoCode(theClass) and (isinstance(theClass, IClass) or isinstance(theClass, IInterface)) and not theClass.isStereotyped("Cxx.CLI.Indexer"):
        visibility = theClass.getVisibility()
        if visibility == ObVisibilityModeEnum.PUBLIC:
          publicClasses.add (theClass)
        elif visibility == ObVisibilityModeEnum.PROTECTED:
          protectedClasses.add (theClass)
        elif visibility == ObVisibilityModeEnum.PRIVATE:
          privateClasses.add (theClass)      
        elif visibility == ObVisibilityModeEnum.VISIBILITY_UNDEFINED:
          privateClasses.add (theClass)
        else:
          privateClasses.add (theClass)
    
    # Add comment if there are some inner classes
    if (len (privateClasses) > 0) or (len (protectedClasses) > 0) or (len (publicClasses) > 0):
      out.println("//inner classes")
      out.println()
    
    # Private and Undefined theClasses
    if len (privateClasses) > 0:
      out.println("private:")
      out.println()
      for theClass in privateClasses:
        out.println(ENG.evalAct("ClassDeclarationHxx", theClass))
        out.println(ENG.evalAct("ClassDefinitionHxx", theClass))
      out.println()
    
    # Protected theClasses      
    if len (protectedClasses) > 0:
      out.println("protected:")
      out.println()
      for theClass in protectedClasses:
        out.println(ENG.evalAct("ClassDeclarationHxx", theClass))
        out.println(ENG.evalAct("ClassDefinitionHxx", theClass))
      out.println()
  
    # Public theClasses
    if len (publicClasses) > 0:
      out.println("public:")
      out.println()
      for theClass in publicClasses:
        out.println(ENG.evalAct("ClassDeclarationHxx", theClass))
        out.println(ENG.evalAct("ClassDefinitionHxx", theClass))
      out.println()
