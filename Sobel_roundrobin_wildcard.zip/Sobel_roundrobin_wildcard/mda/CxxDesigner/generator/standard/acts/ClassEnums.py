#
# Template ClassEnums
# Binded variables
#   CXX      facilities for Cxx specific production and navigation
#   GEN      facilities for code production
#   MDL      facilities for model navigation and condition testing
#   ENG      ACT ENG (used to call another template))
#
################################################################################
# Local utilities functions 
#    naming rules:
#       - if the utility function directly prints out the generated code it must be named printXXXXX  
#         where XXXX is expected to summarize the function role
#       - if the utility function return a piece of generated code as a string it must be name makeXXXXXX 
#         where XXXX is expected to summarize the function role
#       - if the utility function is used to get some elements of the model and return a list of model elements (navigation convinience)
#         it must be named modelGetXXXXX where XXXX is expected to summarize the function role
#    other rules:
#       - any utility function takes a model element as first parameter (name it el)
#       - utility function must not define global variables of their own
#
from com.modeliosoft.modelio.cxxdesigner.engine.act import IAct
from com.modeliosoft.modelio.api import *
from com.modeliosoft.modelio.api.model.uml.infrastructure import *
from com.modeliosoft.modelio.api.model.uml.statik import * 
from com.modeliosoft.modelio.api.model import ObUtils
from java.util import ArrayList
import act

class ClassEnums (IAct):

################################################################################
# Generation code
#

  def run(self, ctx, el):
    out = ctx.getOutputs()[0]
  
    publicEnumerations = ArrayList()
    protectedEnumerations = ArrayList()
    privateEnumerations = ArrayList()
  
    # Sort all enumerations
    for enumeration in el.getOwnedElement(IEnumeration):
      if not act.isNoCode(enumeration):
        visibility = enumeration.getVisibility()
        if visibility == ObVisibilityModeEnum.PUBLIC:
          publicEnumerations.add (enumeration)
        elif visibility == ObVisibilityModeEnum.PROTECTED:
          protectedEnumerations.add (enumeration)
        elif visibility == ObVisibilityModeEnum.PRIVATE:
          privateEnumerations.add (enumeration)      
        elif visibility == ObVisibilityModeEnum.VISIBILITY_UNDEFINED:
          privateEnumerations.add (enumeration)
        else:
          privateEnumerations.add (enumeration)
  
    # Add comment if there are some enumerations
    if (len (privateEnumerations) > 0) or (len (protectedEnumerations) > 0) or (len (publicEnumerations) > 0):
      out.println("//enumerations")
      out.println()
              
    # Private and Undefined enumerations
    if len (privateEnumerations) > 0:
      out.println("private:")
      out.println()
      for enumeration in privateEnumerations:
        out.println(ENG.evalAct("EnumerationGen", enumeration))
      out.println()
    
    # Protected enumerations      
    if len (protectedEnumerations) > 0:
      out.println("protected:")
      out.println()
      for enumeration in protectedEnumerations:
        out.println(ENG.evalAct("EnumerationGen", enumeration))
      out.println()
  
    # Public enumerations
    if len (publicEnumerations) > 0:
      out.println("public:")
      out.println()
      for enumeration in publicEnumerations:
        out.println(ENG.evalAct("EnumerationGen", enumeration))
      out.println()
