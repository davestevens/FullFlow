from com.modeliosoft.modelio.api import *
from com.modeliosoft.modelio.api.model.uml.infrastructure import *
from com.modeliosoft.modelio.api.model.uml.statik import * 
from com.modeliosoft.modelio.api.model import ObUtils
import act

def isNoCode(el):
  return ObUtils.isTagged(el, "Cxx.NoCode") or ObUtils.isTagged(el, "nocode")

def isExternal(el):
  return el.isStereotyped("Cxx.External")

def isTemplated(el):
  "return true if el is a templated namespace"
  if (isinstance(el, IClass)):
    for tpt in el.getTemplate():
      if (tpt.isStereotyped("Cxx.CLI.TemplateParameter")):
        return 0
    return el.cardTemplate() > 0
  else:
    return 0

def isInline(el):
  return not isPureVirtual(el) \
  and ((ObUtils.isTagged(el, "Cxx.Operation.Disposition") \
  and ObUtils.getTagValues(el, "Cxx.Operation.Disposition")[0] == "inline") \
  or isTemplated(el) or isTemplated(el.getCompositionOwner()))

def isPureVirtual(el):
  return (el.getCompositionOwner().getMetaclassName() == "Interface") or el.isAbstract ()

def isAtRoot(el):
  parent = CXX.getNearestNamespace(el);
  return parent is None or parent.isStereotyped("mda_folder") or parent.getMetaclassName() == "Component";
  
def isInner(el):
  cls = el.getCompositionOwner()
  if cls is not None:
    return cls.getMetaclassName() == "Class" or cls.getMetaclassName() == "Interface"
  else:
    return False

def hasDocumentation(el):
  return not ObUtils.getNoteContent(el, CXX.getDescriptionNote()) is None or not ObUtils.getNoteContent(el, "comment") is None

def makeCopyright(el):
  return GEN.makeCopyright(el)

def makeBrief(el):
  notes = GEN.getModifiableNotes(el, "comment")
  if len(notes) > 0:
    ret = "\\brief "
  else:
    ret = ""
  for s in notes:
    ret += s
    if (not s.endswith("\n")):
      ret += "\n"
  return ret 

def makeDescription(el):
  notes = GEN.getModifiableNotes(el, CXX.getDescriptionNote())
  ret = ""
  for s in notes:
    ret += s
    if (not s.endswith("\n")):
      ret += "\n"
  return ret

def makeParams(el):
  ret = ""
  for parameter in el.getIO():
    if (not act.isNoCode(parameter)):
      ret += "\\param " + CXX.makeCxxName(parameter) + "\n"
      ret += makeDescription (parameter)
  return ret

def makeDocumentationComment(el):
  if hasDocumentation(el):
    ret = "/**\n"
    ret += makeBrief(el)
    if isinstance(el, IOperation):
      ret += makeParams(el)
    ret += makeDescription(el)
    ret += "**/"
  else:
    ret = ""
  return ret

def getDataTypes(el):
  ret=[]
  for dt in el.getOwnedElement(IDataType):
    if (dt.getVisibility().equals(el.getVisibility()) and not isNoCode(dt)):
	    ret.append(dt)
  return ret
  
def makeCLIVisibility(el):
  if not act.isInner(el):
      visibility = el.getVisibility()
      if visibility == ObVisibilityModeEnum.PUBLIC:
        return "public "
      elif visibility == ObVisibilityModeEnum.PRIVATE:
        return "private "
      else:
        return ""
  else:
    return ""

def printCLIAttribute(out, el):
  note = ObUtils.getNoteContent(el, "Cxx.CLI.Attribute")
  if note is not None:
    lines = note.split('\n')
    for l in lines:
      if l != "":
        out.println("[ " + l.strip(" \t\n[]") + " ]")  