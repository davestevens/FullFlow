#
# Template ClassEventsCLI
# Binded variables
#   CXX      facilities for Cxx specific production and navigation
#   GEN      facilities for code production
#   MDL      facilities for model navigation and condition testing
#   ENG      ACT ENG (used to call another template))
#
################################################################################
# Local utilities functions 
#    naming rules:
#       - if the utility function directly prints out the generated code it must be named printXXXXX  
#         where XXXX is expected to summarize the function role
#       - if the utility function return a piece of generated code as a string it must be name makeXXXXXX 
#         where XXXX is expected to summarize the function role
#       - if the utility function is used to get some elements of the model and return a list of model elements (navigation convinience)
#         it must be named modelGetXXXXX where XXXX is expected to summarize the function role
#    other rules:
#       - any utility function takes a model element as first parameter (name it el)
#       - utility function must not define global variables of their own
#
from com.modeliosoft.modelio.cxxdesigner.engine.act import IAct
from com.modeliosoft.modelio.api import *
from com.modeliosoft.modelio.api.model.uml.infrastructure import *
from com.modeliosoft.modelio.api.model.uml.statik import *
from com.modeliosoft.modelio.api.model.uml.behavior.common import * 
from com.modeliosoft.modelio.api.model import ObUtils
from java.util import ArrayList
import act

class ClassEventsCLI (IAct):

################################################################################
# Generation code
#

  def run(self, ctx, el):
    out = ctx.getOutputs()[0]
  
    publicEvents = ArrayList()
    protectedEvents = ArrayList()
    privateEvents = ArrayList()

    # Sort all events 
    for event in el.getOwnedElement(ISignal):
      if event.isStereotyped ("Cxx.CLI.Event") and not act.isNoCode(event):
        visibility = ObUtils.getTagValue(event, "Cxx.CLI.Visibility")
        
        if visibility == "public":
          publicEvents.add (event)
        elif visibility == "protected":
          protectedEvents.add (event)
        elif visibility == "private":
          privateEvents.add (event)      
        else:
          privateEvents.add (event)
    
    if (len (publicEvents) > 0):
      out.println(" public:")
      for event in publicEvents:
        out.println(ENG.evalAct("EventGenCLI", event))
    
    if (len (protectedEvents) > 0):
      out.println(" protected:")
      for event in protectedEvents:
        out.println(ENG.evalAct("EventGenCLI", event))
    
    if (len (privateEvents) > 0):
      out.println(" private:")
      for event in privateEvents:
        out.println(ENG.evalAct("EventGenCLI", event))