#
# Template OperationGenCxx
# Binded variables
#   CXX      facilities for Cxx specific production and navigation
#   GEN      facilities for code production
#   MDL      facilities for model navigation and condition testing
#   ENG      ACT ENG (used to call another template))
#
################################################################################
# Local utilities functions 
#    naming rules:
#       - if the utility function directly prints out the generated code it must be named printXXXXX  
#         where XXXX is expected to summarize the function role
#       - if the utility function return a piece of generated code as a string it must be name makeXXXXXX 
#         where XXXX is expected to summarize the function role
#       - if the utility function is used to get some elements of the model and return a list of model elements (navigation convinience)
#         it must be named modelGetXXXXX where XXXX is expected to summarize the function role
#    other rules:
#       - any utility function takes a model element as first parameter (name it el)
#       - utility function must not define global variables of their own
#
from com.modeliosoft.modelio.cxxdesigner.engine.act import IAct
from com.modeliosoft.modelio.api.model import ObUtils
from com.modeliosoft.modelio.api.model.uml.infrastructure import *
from com.modeliosoft.modelio.api.model.uml.statik import *

class OperationGenCxx (IAct):
  def printQualifiedSignature(self, ctx, out, op):
    ctx.setProperty("forDefinition", 1)
    out.print(self.makeTemplate(op.getOwner()))
    out.print(self.makeTemplate(op))
    out.print(ENG.evalAct("OperationSignature", op))
    ctx.unsetProperty("forDefinition")
  
  def printThrow(self, out, op):
    values = CXX.getThrown(op)
    if (len(values) > 0):
      out.print(" throw (")
      
      ret = ""
      for tt in values:
        ret += tt + ", "
      ret = ret.rstrip(", ")
      out.print(ret)
      out.print(")")
  
  def printBody(self, out, op):
    out.println(ENG.evalAct("OperationCode", op))

  def makeTemplateDeclaration (self, el, typeScope):
    s = ""
    
    param = el.getOwnedParameterElement()
    if (el.isValueParameter()):
      s+= CXX.makeCxxDeclBase(el, typeScope)
    elif (not param is None):
        if (isinstance(param, IAttribute)):
          s += CXX.makeCxxDecl(param, nameScope,typeScope)
        elif (isinstance(param, IClass)):
          if (param.isTemplated()):
            s += "template <" + makeFormalTplParamList(param) + "> "
          s += "class " + CXX.makeCxxName(param)
        elif (isinstance(param, IDataType)):
          s += "typename " + CXX.makeCxxName(param)
    else:
      s += "class " + CXX.makeCxxName(el)
    
      defaultType = el.getDefaultType()
      defaultValue = el.getDefaultValue()
      if (not defaultType is None):
        s += " = " + CXX.makeScopedNamespacedPath(defaultType, typeScope)
      elif (not defaultValue is None and defaultValue != ""):
        s += " = " + defaultValue
    
    return s


  def makeCppTemplate(self, templates):
    template = "template <"
    for templateParameter in templates:
      template += self.makeTemplateDeclaration(templateParameter,templateParameter.getCompositionOwner().getCompositionOwner()) + ", "
    template = template.rstrip(", ")
    template += "> "
    return template
    
  def makeCLITemplate(self, templates):
    template = "generic <"
    whereClause = ""
    for templateParameter in templates:
      template += self.makeTemplateDeclaration(templateParameter,templateParameter.getCompositionOwner().getCompositionOwner()) + ", "
      if ObUtils.isTagged(templateParameter, "Cxx.CLI.ConstraintClause"):
        if not whereClause:
          whereClause = "\nwhere "
        whereClause += templateParameter.getName() + " : " + ObUtils.getTagValue(templateParameter, "Cxx.CLI.ConstraintClause") + "\n"       
    template = template.rstrip(", ")
    template += "> "
    return template + whereClause
  
  def makeTemplate(self, el):
    template = ""
    if (el.cardTemplate() > 0):
      templates = el.getTemplate()
      CLITemplates = filter(lambda t : t.isStereotyped("Cxx.CLI.TemplateParameter"), templates)
      if CLITemplates and len(CLITemplates) != len(templates):
        # Error : all the template parameters should be CLI or not. Can't mix template and generic
        pass
      elif CLITemplates:
        template = self.makeCLITemplate(CLITemplates)
      elif templates:
        template = self.makeCppTemplate(templates)
    return template

################################################################################
# Generation code
#
  def run(self, ctx, el):
    out = ctx.getOutputs()[0]
    if (ObUtils.isTagged(el, "Cxx.TypeExpr.Body")):
      out.print(ObUtils.getTagValue(el, "Cxx.TypeExpr.Body"))
    else:
      self.printQualifiedSignature(ctx, out, el)
    self.printThrow(out, el)
    self.printBody(out, el)

