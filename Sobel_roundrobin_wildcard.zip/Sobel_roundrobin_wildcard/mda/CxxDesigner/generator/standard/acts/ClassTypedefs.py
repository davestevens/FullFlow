#
# Template ClassTypedefs
# Binded variables
#   CXX      facilities for Cxx specific production and navigation
#   GEN      facilities for code production
#   MDL      facilities for model navigation and condition testing
#   ENG      ACT ENG (used to call another template))
#
################################################################################
# Local utilities functions 
#    naming rules:
#       - if the utility function directly prints out the generated code it must be named printXXXXX  
#         where XXXX is expected to summarize the function role
#       - if the utility function return a piece of generated code as a string it must be name makeXXXXXX 
#         where XXXX is expected to summarize the function role
#       - if the utility function is used to get some elements of the model and return a list of model elements (navigation convinience)
#         it must be named modelGetXXXXX where XXXX is expected to summarize the function role
#    other rules:
#       - any utility function takes a model element as first parameter (name it el)
#       - utility function must not define global variables of their own
#
from com.modeliosoft.modelio.cxxdesigner.engine.act import IAct
from com.modeliosoft.modelio.api import *
from com.modeliosoft.modelio.api.model.uml.infrastructure import *
from com.modeliosoft.modelio.api.model.uml.statik import * 
from com.modeliosoft.modelio.api.model import ObUtils
from java.util import ArrayList
import act

class ClassTypedefs (IAct):
  
  def isDeclaration(self, el):
    return (ObUtils.isTagged(el, "Cxx.TypeExpr")) or (el.cardTemplateInstanciation() > 0)
  
  
  
  def printTypeDefDeclaration(self, out, el):
    out.println(ENG.evalAct("TypeDefGen", el))
  


################################################################################
# Generation code
#
  def run(self, ctx, el):
    out = ctx.getOutputs()[0]
  
    publicDataTypes = ArrayList()
    protectedDataTypes = ArrayList()
    privateDataTypes = ArrayList()
  
    # Sort all typedefs
    for datatype in el.getOwnedElement(IDataType):
      if not act.isNoCode(datatype) and self.isDeclaration(datatype):
        visibility = datatype.getVisibility()
        if visibility == ObVisibilityModeEnum.PUBLIC:
          publicDataTypes.add (datatype)
        elif visibility == ObVisibilityModeEnum.PROTECTED:
          protectedDataTypes.add (datatype)
        elif visibility == ObVisibilityModeEnum.PRIVATE:
          privateDataTypes.add (datatype)      
        elif visibility == ObVisibilityModeEnum.VISIBILITY_UNDEFINED:
          privateDataTypes.add (datatype)
        else:
          privateDataTypes.add (datatype)
  
    # Add comment if there are some typedefs
    if (len (privateDataTypes) > 0) or (len (protectedDataTypes) > 0) or (len (publicDataTypes) > 0):
      out.println("//typedefs")
      out.println()
  
    # Private and Undefined datatypes
    if len (privateDataTypes) > 0:
      out.println("private:")
      out.println()
      for datatype in privateDataTypes:
        self.printTypeDefDeclaration(out, datatype)
      out.println()
    
    # Protected datatypes      
    if len (protectedDataTypes) > 0:
      out.println("protected:")
      out.println()
      for datatype in protectedDataTypes:
        self.printTypeDefDeclaration(out, datatype)
      out.println()
  
    # Public datatypes
    if len (publicDataTypes) > 0:
      out.println("public:")
      out.println()
      for datatype in publicDataTypes:
        self.printTypeDefDeclaration(out, datatype)
      out.println()
