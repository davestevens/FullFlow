#
# Template ForwardDeclsOtherNamespaces
# Binded variables
#   CXX      facilities for Cxx specific production and navigation
#   GEN      facilities for code production
#   MDL      facilities for model navigation and condition testing
#   ENG      ACT ENG (used to call another template))
#
################################################################################
# Local utilities functions 
#    naming rules:
#       - if the utility function directly prints out the generated code it must be named printXXXXX  
#         where XXXX is expected to summarize the function role
#       - if the utility function return a piece of generated code as a string it must be name makeXXXXXX 
#         where XXXX is expected to summarize the function role
#       - if the utility function is used to get some elements of the model and return a list of model elements (navigation convinience)
#         it must be named modelGetXXXXX where XXXX is expected to summarize the function role
#    other rules:
#       - any utility function takes a model element as first parameter (name it el)
#       - utility function must not define global variables of their own
#
from com.modeliosoft.modelio.cxxdesigner.engine.act import IAct
from com.modeliosoft.modelio.api.model import ObUtils
from com.modeliosoft.modelio.api.model.uml.infrastructure import *
from com.modeliosoft.modelio.api.model.uml.statik import *
import act

class ForwardDeclsOtherNamespaces (IAct):
  def printForwardDeclarations(self, out, el):
    out.println(ENG.evalAct("ClassForwardDeclaration", el))
  
  def printOpenNamespace(self, out, el):
    for ns in CXX.getNamespacePackages(el):
      out.printf("namespace %s {\n", [CXX.makeCxxName(ns)])
  
  def printCloseNamespace(self, out, el):
    for ns in CXX.getNamespacePackages(el):
      out.printf("} // namespace %s\n", [CXX.makeCxxName(ns)])

# end define

################################################################################
# Generation code
#
  def run(self, ctx, el):
    out = ctx.getOutputs()[0]
  
    namespace = CXX.getNearestNamespace(el)
    if (not namespace is None):
      values = CXX.getForwardDeclNamespacesEx(el)
      if (len(values) > 0):
        out.println("// other forward declarations")
    
        for namespacedEl in values:
          elNamespace = CXX.getNearestNamespace(namespacedEl)
          hasNamespace = not elNamespace is None and not isinstance(namespacedEl, IDataType) and not ObUtils.isTagged(elNamespace, "Cxx.Package.NoNamespace") and not act.isAtRoot(elNamespace)
          
          if (hasNamespace):
              self.printOpenNamespace(out, namespacedEl)
          
          self.printForwardDeclarations(out, namespacedEl)

          if (hasNamespace):
            self.printCloseNamespace(out, namespacedEl)
          
