#
# Template ClassDeclarationHxx
# Binded variables
#   CXX      facilities for Cxx specific production and navigation
#   GEN      facilities for code production
#   MDL      facilities for model navigation and condition testing
#   ENG      ACT ENG (used to call another template))
#
################################################################################
# Local utilities functions 
#    naming rules:
#       - if the utility function directly prints out the generated code it must be named printXXXXX  
#         where XXXX is expected to summarize the function role
#       - if the utility function return a piece of generated code as a string it must be name makeXXXXXX 
#         where XXXX is expected to summarize the function role
#       - if the utility function is used to get some elements of the model and return a list of model elements (navigation convinience)
#         it must be named modelGetXXXXX where XXXX is expected to summarize the function role
#    other rules:
#       - any utility function takes a model element as first parameter (name it el)
#       - utility function must not define global variables of their own
#
from com.modeliosoft.modelio.cxxdesigner.engine.act import IAct
from com.modeliosoft.modelio.api import *
from com.modeliosoft.modelio.api.model.uml.infrastructure import *
from com.modeliosoft.modelio.api.model.uml.statik import * 
from com.modeliosoft.modelio.api.model import ObUtils
import act

class ClassDeclarationHxx (IAct):

  def makeCLIClassAccess(self, el):
    if (self.isCLI and not ObUtils.isTagged(el, "Cxx.Union")) or self.isCLIInterface or self.isCLIAttribute:
      return act.makeCLIVisibility(el);
    else:
      return ""

  
  def makeCLIClassKeywordPrefix(self, el):
    if (self.isCLI and not ObUtils.isTagged(el, "Cxx.Union")) or self.isCLIAttribute:
      if el.isElementary():
        return "value "
      else:
        return "ref "
    elif self.isCLIInterface:
      return "interface "
    else:
      return ""
      
  def makeCLIModifier(self, el):
    mod = ""
    if self.isCLI and not ObUtils.isTagged(el, "Cxx.Union"):
      if el.isAbstract():
        mod = " abstract"
      elif el.isLeaf():
        mod = " sealed"
    return mod
  
  def makeCLIDeclareAttributeUsage(self, el):
    prefix = ""
    postfix = ""
    att = ""
    if self.isCLIAttribute:
      # Cxx.Attribute.Targets
      targets = ObUtils.getTagValues(el, "Cxx.CLI.Attribute.Targets")
      if targets is not None:
        for t in targets:
          att += "System::AttributeTargets::" + t + " | "
        att = att.rstrip(" | ")
      # Cxx.CLI.Attribute.Inherited
      if ObUtils.isTagged(el, "Cxx.CLI.Attribute.Inherited"):
        if att != "":
          att += ", "
        att += "Inherited=true"
      # Cxx.CLI.Attribute.AllowMultiple
      if ObUtils.isTagged(el, "Cxx.CLI.Attribute.AllowMultiple"):
        if att != "":
          att += ", "
        att += "AllowMultiple=true"
        
      if att != "":
        prefix = "[System::AttributeUsage("
        postfix = ")]"
        
    return prefix + att + postfix
  
  def makeClassKeyword(self, el):
    if ObUtils.isTagged(el, "Cxx.Struct"):
      return "struct"
    elif ObUtils.isTagged(el, "Cxx.Union"):
      return "union"
    else:
      return "class"
  
  def makeDeclarationSpecifier(self, el):
    value = ObUtils.getTagValue(el, "Cxx.DeclarationSpecifier")
    if value is None:
      declspec = " "
    else:
      declspec = " " + value + " "
    return declspec  
  
  def makeSpecifiers(self, el):
    decl = ""
    values = ObUtils.getTagValues(el, "Cxx.Specifier")
    if (not values is None):
      for spec in values:
        decl += spec + " "
    
    return decl
  
  def makeTemplateDeclaration (self, el, typeScope):
    s = ""
    
    param = el.getOwnedParameterElement()
    if (el.isValueParameter()):
      s+= CXX.makeCxxDeclBase(el, typeScope)
    elif (not param is None):
        if (isinstance(param, IAttribute)):
          s += CXX.makeCxxDecl(param, nameScope,typeScope)
        elif (isinstance(param, IClass)):
          if (param.isTemplated()):
            s += "template <" + makeFormalTplParamList(param) + "> "
          s += "class " + CXX.makeCxxName(param)
        elif (isinstance(param, IDataType)):
          s += "typename " + CXX.makeCxxName(param)
    else:
      s += "class " + CXX.makeCxxName(el)
    
      defaultType = el.getDefaultType()
      defaultValue = el.getDefaultValue()
      if (not defaultType is None):
        s += " = " + CXX.makeScopedNamespacedPath(defaultType, typeScope)
      elif (not defaultValue is None and defaultValue != ""):
        s += " = " + defaultValue
    
    return s

  def makeCppTemplate(self, templates):
    template = "template <"
    for templateParameter in templates:
      template += self.makeTemplateDeclaration(templateParameter,templateParameter.getCompositionOwner().getCompositionOwner()) + ", "
    template = template.rstrip(", ")
    template += "> "
    return template
    
  def makeCLITemplate(self, templates):
    template = "generic <"
    whereClause = ""
    for templateParameter in templates:
      template += self.makeTemplateDeclaration(templateParameter,templateParameter.getCompositionOwner().getCompositionOwner()) + ", "
      if ObUtils.isTagged(templateParameter, "Cxx.CLI.ConstraintClause"):
        if not whereClause:
          whereClause = "\nwhere "
        whereClause += templateParameter.getName() + " : " + ObUtils.getTagValue(templateParameter, "Cxx.CLI.ConstraintClause") + "\n"       
    template = template.rstrip(", ")
    template += "> "
    return template + whereClause
  
  def makeTemplate(self, el):
    template = ""
    if (el.cardTemplate() > 0):
      templates = el.getTemplate()
      CLITemplates = filter(lambda t : t.isStereotyped("Cxx.CLI.TemplateParameter"), templates)
      if CLITemplates and len(CLITemplates) != len(templates):
        # Error : all the template parameters should be CLI or not. Can't mix template and generic
        pass
      elif CLITemplates:
        template = self.makeCLITemplate(CLITemplates)
      elif templates:
        template = self.makeCppTemplate(templates)
    return template


  def makeBaseClause(self, el):
    generalizations = CXX.getGeneralizations(el)
    
    if len(generalizations) > 0:
      ret = " : "
      for gen in generalizations:
        ret += gen + ", "
      ret = ret.rstrip(", ")
    elif self.isCLIAttribute:
      ret = " : System::Attribute"
    else:
      ret = ""
    
    return ret
  
################################################################################
# Generation code
#

  def run(self, ctx, el):
    out = ctx.getOutputs()[0]
    
    self.isCLI = el.isStereotyped("Cxx.CLI.Class")
    self.isCLIInterface = el.isStereotyped("Cxx.CLI.Interface")
    self.isCLIAttribute = el.isStereotyped("Cxx.CLI.Attribute")
  
    if act.hasDocumentation(el):
      out.println(act.makeDocumentationComment(el))
    out.println(self.makeCLIDeclareAttributeUsage(el))
    act.printCLIAttribute(out, el)
    out.print(self.makeSpecifiers(el))
    out.print(self.makeTemplate(el))
    out.print(self.makeCLIClassAccess(el))
    out.print(self.makeCLIClassKeywordPrefix(el))
    out.print(self.makeClassKeyword(el))
    out.print(self.makeDeclarationSpecifier(el))
    out.print(CXX.makeCxxName(el))
    out.print(self.makeCLIModifier(el))
    out.print(self.makeBaseClause(el))
   
