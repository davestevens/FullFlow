#
# Template ClassFeatures
# Binded variables
#   CXX      facilities for Cxx specific production and navigation
#   GEN      facilities for code production
#   MDL      facilities for model navigation and condition testing
#   ENG      ACT ENG (used to call another template))
#
################################################################################
# Local utilities functions 
#    naming rules:
#       - if the utility function directly prints out the generated code it must be named printXXXXX  
#         where XXXX is expected to summarize the function role
#       - if the utility function return a piece of generated code as a string it must be name makeXXXXXX 
#         where XXXX is expected to summarize the function role
#       - if the utility function is used to get some elements of the model and return a list of model elements (navigation convinience)
#         it must be named modelGetXXXXX where XXXX is expected to summarize the function role
#    other rules:
#       - any utility function takes a model element as first parameter (name it el)
#       - utility function must not define global variables of their own
#
from com.modeliosoft.modelio.cxxdesigner.engine.act import IAct
from com.modeliosoft.modelio.api import *
from com.modeliosoft.modelio.api.model.uml.infrastructure import *
from com.modeliosoft.modelio.api.model.uml.statik import * 
from com.modeliosoft.modelio.api.model import ObUtils
from java.util import ArrayList
import act


class ClassFeatures (IAct):

################################################################################
# Generation code
#
# This template will group the class features (attributes, operations and associations)
# by visibility. Then it will call the proper generation template for each of them

  def run(self, ctx, el):
    out = ctx.getOutputs()[0]
    
    publicAttributes = ArrayList()
    protectedAttributes = ArrayList()
    privateAttributes = ArrayList()
    publicOperations = ArrayList()
    protectedOperations = ArrayList()
    privateOperations = ArrayList()
    publicAssociations = ArrayList()
    protectedAssociations = ArrayList()
    privateAssociations = ArrayList()

  
    # Sort all attributes 
    for attribute in el.getPart(IAttribute):
      if not act.isNoCode(attribute):
        visibility = attribute.getVisibility()
        if visibility == ObVisibilityModeEnum.PUBLIC:
          publicAttributes.add (attribute)
        elif visibility == ObVisibilityModeEnum.PROTECTED:
          protectedAttributes.add (attribute)
        elif visibility == ObVisibilityModeEnum.PRIVATE:
          privateAttributes.add (attribute)      
        elif visibility == ObVisibilityModeEnum.VISIBILITY_UNDEFINED:
          privateAttributes.add (attribute)
        else:
          privateAttributes.add (attribute)

    # Sort all associations
    for association in el.getPart(IAssociationEnd):
      if association.isNavigable() and not act.isNoCode(association):
        visibility = association.getVisibility()
        if visibility == ObVisibilityModeEnum.PUBLIC:
          publicAssociations.add (association)
        elif visibility == ObVisibilityModeEnum.PROTECTED:
          protectedAssociations.add (association)
        elif visibility == ObVisibilityModeEnum.PRIVATE:
          privateAssociations.add (association)
        elif visibility == ObVisibilityModeEnum.VISIBILITY_UNDEFINED:
          privateAssociations.add (association)
        else:
          privateAssociations.add (association)

    # Sort all operations
    for operation in el.getPart(IOperation):
      if not act.isNoCode(operation):
        visibility = operation.getVisibility()
        if visibility == ObVisibilityModeEnum.PUBLIC:
          publicOperations.add (operation)
        elif visibility == ObVisibilityModeEnum.PROTECTED:
          protectedOperations.add (operation)
        elif visibility == ObVisibilityModeEnum.PRIVATE:
          privateOperations.add (operation)
        elif visibility == ObVisibilityModeEnum.VISIBILITY_UNDEFINED:
          privateOperations.add (operation)
        else:
          privateOperations.add (operation)

    # Public features
    #
    if ( (len (publicAttributes) + len (publicAssociations) + len (publicOperations)) > 0):
      out.println(" public:")
      #   -> attributes
      for attribute in publicAttributes:
        out.println(ENG.evalAct("AttributeGen", attribute))
      #   -> associations
      for association in publicAssociations:
        out.println(ENG.evalAct("AssociationGen", association))
      #   -> operations
      for operation in publicOperations:
        out.println(ENG.evalAct("OperationGenHxx", operation))
      out.println()

    # protected features
    #
    if ( (len (protectedAttributes) + len (protectedAssociations) + len (protectedOperations)) > 0):
      out.println(" protected:")
      #   -> attributes
      for attribute in protectedAttributes:
        out.println(ENG.evalAct("AttributeGen", attribute))
      #   -> associations
      for association in protectedAssociations:
        out.println(ENG.evalAct("AssociationGen", association))
      #   -> operations
      for operation in protectedOperations:
        out.println(ENG.evalAct("OperationGenHxx", operation))
      out.println()

    # private features
    #
    if ( (len (privateAttributes) + len (privateAssociations) + len (privateOperations)) > 0):
      out.println(" private:")
      #   -> attributes
      for attribute in privateAttributes:
        out.println(ENG.evalAct("AttributeGen", attribute))
      #   -> associations
      for association in privateAssociations:
        out.println(ENG.evalAct("AssociationGen", association))
      #   -> operations
      for operation in privateOperations:
        out.println(ENG.evalAct("OperationGenHxx", operation))
      out.println()
