#
# Template ClassIncludesHxx
# Binded variables
#   CXX      facilities for Cxx specific production and navigation
#   GEN      facilities for code production
#   MDL      facilities for model navigation and condition testing
#   ENG      ACT ENG (used to call another template))
#
################################################################################
# Local utilities functions 
#    naming rules:
#       - if the utility function directly prints out the generated code it must be named printXXXXX  
#         where XXXX is expected to summarize the function role
#       - if the utility function return a piece of generated code as a string it must be name makeXXXXXX 
#         where XXXX is expected to summarize the function role
#       - if the utility function is used to get some elements of the model and return a list of model elements (navigation convinience)
#         it must be named modelGetXXXXX where XXXX is expected to summarize the function role
#    other rules:
#       - any utility function takes a model element as first parameter (name it el)
#       - utility function must not define global variables of their own
#
from com.modeliosoft.modelio.cxxdesigner.engine.act import IAct
from com.modeliosoft.modelio.api.model import ObUtils
from com.modeliosoft.modelio.api import *
from com.modeliosoft.modelio.api.model.uml.infrastructure import *
from com.modeliosoft.modelio.api.model.uml.statik import *
import act


class ClassIncludesHxx (IAct):

  def hasInnerClass(self, el):
    return el.cardOwnedElement(IClass) > 0

  def printInnerClassInheritance(self, out, el):
    for sub in el.getOwnedElement():
      if (isinstance(sub, IClass) or isinstance(sub, IClass)):
        for s in CXX.getAutoIncludes(sub):
          out.printf("#include <%s>\n", [s])
          self.printInnerClassInheritance(out, sub)

################################################################################
# Generation code
#

  def run(self, ctx, el):
    out = ctx.getOutputs()[0]
    
    ownerPackage = CXX.makeHeaderFilename(el.getCompositionOwner())
    if (len (ownerPackage) > 0):
      out.println("//owner package header file")
      out.printf("#include \"%s\"\n", [ownerPackage])

    # lib includes
    libs = CXX.getLibIncludes(el)
    if len(libs) > 0:
      out.println("//includes for used library types")
      for s in libs:
        out.printf("#include <%s>\n", [s])
      out.println()
    
    # automatic includes
    auto = CXX.getAutoIncludes(el)
    if len(auto) > 0:
      out.println("//automatic includes (friends, associated classes, etc)")
      for s in auto:
        out.printf("#include \"%s\"\n", [s])
      out.println()
    
    autoImports = CXX.getAutoImportedIncludes(el)
    if len(autoImports) > 0:
      out.println("//automatic imported includes (friends, associated classes, etc)")
      for s in autoImports:
        out.printf("#include %s\n", [s])
      out.println()
    
    if (isinstance(el, IClass)):
      if (self.hasInnerClass(el)):
        out.println("//inner class inheritance")
        self.printInnerClassInheritance(out, el)
    
    # use includes
    headerUses = CXX.getHeaderUseIncludes(el)
    if len(headerUses) > 0:
      out.println("//includes for used external code")
      for s in headerUses:
        out.printf("#include <%s>\n", [s])
      out.println()

    # ports includes
    #<include tpl="CxxPortIncludes"/>
    
    # notes
    notes = GEN.getModifiableNotes(el, "Cxx.Use.Header")
    if len(notes) > 0:
      for s in notes:
        out.println(s)
      out.println()
