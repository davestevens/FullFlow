#
# Template EnumerationGen
# Binded variables
#   CXX      facilities for Cxx specific production and navigation
#   GEN      facilities for code production
#   MDL      facilities for model navigation and condition testing
#   ENG      ACT ENG (used to call another template))
#
################################################################################
# Local utilities functions 
#    naming rules:
#       - if the utility function directly prints out the generated code it must be named printXXXXX  
#         where XXXX is expected to summarize the function role
#       - if the utility function return a piece of generated code as a string it must be name makeXXXXXX 
#         where XXXX is expected to summarize the function role
#       - if the utility function is used to get some elements of the model and return a list of model elements (navigation convinience)
#         it must be named modelGetXXXXX where XXXX is expected to summarize the function role
#    other rules:
#       - any utility function takes a model element as first parameter (name it el)
#       - utility function must not define global variables of their own
#
from com.modeliosoft.modelio.cxxdesigner.engine.act import IAct
from com.modeliosoft.modelio.api import *
from com.modeliosoft.modelio.api.model.uml.infrastructure import *
from com.modeliosoft.modelio.api.model.uml.statik import * 
from com.modeliosoft.modelio.api.model import ObUtils
from java.util import ArrayList
import act

class EnumerationGen (IAct):

  def printCLIHeader(self, out, el):
    out.print(act.makeCLIVisibility(el))
    if (ObUtils.isTagged(el, "Cxx.Struct")):
      out.print("enum struct ")
    else:
      out.print("enum class ")
    out.print(CXX.makeCxxName(el))
    etype = ObUtils.getTagValue(el, "Cxx.CLI.EnumerationType")
    if not etype is None:
      out.print (" : " + etype)
    
  def printLiterals(self, out, el):
    literals = el.getValue()
    for i in range(len(literals)):
      literal = literals[i]
      
      value = ObUtils.getTagValue(literal, "Cxx.TypeExpr")
      if not value is None:
        value = " = " + value
      else:
        value = ""
        
      if act.hasDocumentation(literal):
        out.println(act.makeDocumentationComment(literal))
      if (i != (len(literals) - 1)):
        out.println(CXX.makeCxxName(literal) + value + ",")
      else:
        out.println(CXX.makeCxxName(literal) + value)
  


################################################################################
# Generation code
#

  def run(self, ctx, el):
    out = ctx.getOutputs()[0]
  
    if act.hasDocumentation(el):
      out.println(act.makeDocumentationComment(el))
    
    if el.isStereotyped("Cxx.CLI.Enumeration"):
      self.printCLIHeader(out, el)
      out.println(" {")
      self.printLiterals(out, el)
      out.println("};")
    else:
      out.println("typedef enum _" + CXX.makeCxxName(el))
      out.println(" {")
      self.printLiterals(out, el)
      out.println("} " + CXX.makeCxxName(el) + ";")
