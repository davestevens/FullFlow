#
# Template AssociationGenCLI
# Binded variables
#   CXX      facilities for Cxx specific production and navigation
#   GEN      facilities for code production
#   MDL      facilities for model navigation and condition testing
#   ENG      ACT ENG (used to call another template))
#
################################################################################
# Local utilities functions 
#    naming rules:
#       - if the utility function directly prints out the generated code it must be named printXXXXX  
#         where XXXX is expected to summarize the function role
#       - if the utility function return a piece of generated code as a string it must be name makeXXXXXX 
#         where XXXX is expected to summarize the function role
#       - if the utility function is used to get some elements of the model and return a list of model elements (navigation convinience)
#         it must be named modelGetXXXXX where XXXX is expected to summarize the function role
#    other rules:
#       - any utility function takes a model element as first parameter (name it el)
#       - utility function must not define global variables of their own
#
from com.modeliosoft.modelio.cxxdesigner.engine.act import IAct
from com.modeliosoft.modelio.api import *
from com.modeliosoft.modelio.api.model.uml.infrastructure import *
from com.modeliosoft.modelio.api.model.uml.statik import * 
from com.modeliosoft.modelio.api.model import ObUtils
from java.util import ArrayList
import act

INDENT = "    "             # four white spaces

class AssociationGenCLI (IAct):
  
  def isAbstract(Propertyself, el):
    return ObUtils.isTagged(el, "Cxx.CLI.Abstract")

  def isSealed(Propertyself, el):
    return ObUtils.isTagged(el, "Cxx.CLI.Sealed")

  def isOverride(Propertyself, el):
    return ObUtils.isTagged(el, "Cxx.CLI.Override")

  def makeMemberDeclaration(self, assoc):
    # standard case
    # declaration syntax is build as:
    #  decl          = $specifiers $decoratedtype $namespacedname$bindings $init;
    #  decoratedtype = $containerpointers $container($type)
    #  type          = $basetype $pointers
    # 
    # example:
    #  static std::vector<int*> C1::assoc;
    
    # compute declaration
    decl = GEN.makeHxxSignature(assoc)
    
    return decl
  
  def printAssociationDeclaration(self, out, el):
    if act.hasDocumentation(el):
      out.println(act.makeDocumentationComment(el))
    
    act.printCLIAttribute(out, el)
    out.print(INDENT + self.makeMemberDeclaration(el))
        
    if (el.getChangeable() == ObKindOfAccessEnum.READ):
      read = True
      write = False
    elif (el.getChangeable() == ObKindOfAccessEnum.WRITE):
      read = False
      write = True
    elif (el.getChangeable() == ObKindOfAccessEnum.READ_WRITE):
      read = True
      write = True
    else:
      read = False
      write = False
    
    ret = ""
    if (read or write):
      endSpecifiers = ""
      if (self.isAbstract(el)):
        endSpecifiers += " abstract"
      if (self.isSealed(el)):
        endSpecifiers += " sealed"
      if (self.isOverride(el)):
        endSpecifiers += " override"
      
      type = GEN.makeType (el)
      
      ret += " {\n"
      if (read):
        getterVisibility = ObUtils.getTagValue(el, "Cxx.CLI.GetterVisibility")
        if (not getterVisibility is None):
          ret += getterVisibility.lower() + ":\n"
        
        ret += type + " get()" + endSpecifiers
        
        getterCode = ObUtils.getNoteContent(el, "Cxx.CLI.GetterCode")
        if (not getterCode is None):
          ret += " {";
          for note in GEN.getModifiableNotes(el, "Cxx.CLI.GetterCode"):
            ret += "\n" + note
          ret += "}";
        else:
          ret += ";\n"
      if (write):
        setterVisibility = ObUtils.getTagValue(el, "Cxx.CLI.SetterVisibility")
        if (not setterVisibility is None and setterVisibility != getterVisibility):
          ret += setterVisibility.lower() + ":\n"
        ret += "void set(" + type + "value)" + endSpecifiers
        setterCode = ObUtils.getNoteContent(el, "Cxx.CLI.SetterCode")
        if (not setterCode is None):
          ret += " {";
          for note in GEN.getModifiableNotes(el, "Cxx.CLI.SetterCode"):
            ret += "\n" + note
          ret += "}";
        else:
          ret += ";\n"
      ret += "\n}\n"
      out.print(ret)
    else:
      out.print(";")

################################################################################
# Generation code
#

  def run(self, ctx, assoc):
    out = ctx.getOutputs()[0]
    self.printAssociationDeclaration(out, assoc)
