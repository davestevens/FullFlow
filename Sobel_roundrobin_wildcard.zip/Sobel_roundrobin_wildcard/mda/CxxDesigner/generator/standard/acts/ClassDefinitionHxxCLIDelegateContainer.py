#
# Template ClassDefinitionHxxCLIDelegateContainer
# Binded variables
#   CXX      facilities for Cxx specific production and navigation
#   GEN      facilities for code production
#   MDL      facilities for model navigation and condition testing
#   ENG      ACT ENG (used to call another template))
#
################################################################################
# Local utilities functions 
#    naming rules:
#       - if the utility function directly prints out the generated code it must be named printXXXXX  
#         where XXXX is expected to summarize the function role
#       - if the utility function return a piece of generated code as a string it must be name makeXXXXXX 
#         where XXXX is expected to summarize the function role
#       - if the utility function is used to get some elements of the model and return a list of model elements (navigation convinience)
#         it must be named modelGetXXXXX where XXXX is expected to summarize the function role
#    other rules:
#       - any utility function takes a model element as first parameter (name it el)
#       - utility function must not define global variables of their own
#
from com.modeliosoft.modelio.cxxdesigner.engine.act import IAct
from com.modeliosoft.modelio.api import *
from com.modeliosoft.modelio.api.model.uml.infrastructure import *
from com.modeliosoft.modelio.api.model.uml.statik import * 
from com.modeliosoft.modelio.api.model import ObUtils
import act

class ClassDefinitionHxxCLIDelegateContainer (IAct):


################################################################################
# Generation code
#

  def run(self, ctx, el):
    out = ctx.getOutputs()[0]
    
  
    if act.hasDocumentation(el):
      out.println(act.makeDocumentationComment(el))
    out.print(ENG.evalAct("ClassEnums", el))
    out.print(ENG.evalAct("ClassTypedefs", el))
    out.print(ENG.evalAct("ClassFeaturesCLIDelegateContainer", el))
    out.print(ENG.evalAct("ClassMemberNotes", el))
    
