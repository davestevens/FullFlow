#
# Template OperationSignature
# Binded variables
#   CXX      facilities for Cxx specific production and navigation
#   GEN      facilities for code production
#   MDL      facilities for model navigation and condition testing
#   ENG      ACT ENG (used to call another template))
#
################################################################################
# Local utilities functions 
#    naming rules:
#       - if the utility function directly prints out the generated code it must be named printXXXXX  
#         where XXXX is expected to summarize the function role
#       - if the utility function return a piece of generated code as a string it must be name makeXXXXXX 
#         where XXXX is expected to summarize the function role
#       - if the utility function is used to get some elements of the model and return a list of model elements (navigation convinience)
#         it must be named modelGetXXXXX where XXXX is expected to summarize the function role
#    other rules:
#       - any utility function takes a model element as first parameter (name it el)
#       - utility function must not define global variables of their own
#
from com.modeliosoft.modelio.cxxdesigner.engine.act import IAct
from com.modeliosoft.modelio.api.model import ObUtils
from com.modeliosoft.modelio.api import *
from com.modeliosoft.modelio.api.model.uml.infrastructure import *
from com.modeliosoft.modelio.api.model.uml.statik import *
from com.modeliosoft.modelio.cxxdesigner.i18n import CxxMessages 
import act

class OperationSignature (IAct):

  def makeSpecifiers(self, ctx, op):
    res = ""
    if ( not self.forDefinition or act.isInline(op)):
      if (op.isClass()):
        res = "static "        
      if (ObUtils.isTagged(op, "Cxx.Specifier")):
          for s in ObUtils.getTagValues(op, "Cxx.Specifier"):
            if not s == "const":
              res = s + " " + res
    
    if ((res.find("virtual") == -1) and (isinstance (op.getOwner(), IInterface) or act.isPureVirtual(op))):
      res = "virtual " + res
    
    if (res.find("virtual") != -1):
      if (op.isFinal()):
        ctx.getReport().addWarning(CxxMessages.getString ("Warning.generation.invalidSpecifier") + op.getName(),
                                   op,
                                   CxxMessages.getString ("Warning.generation.finalVirtualOperation"))
        res = res.replace ("virtual ", "")
      if (op.isClass()): 
        ctx.getReport().addWarning(CxxMessages.getString ("Warning.generation.invalidSpecifier") + op.getName(),
                                   op,
                                   CxxMessages.getString ("Warning.generation.staticVirtualOperation"))
        res = res.replace ("virtual ", "")
    
    return res
    
  def makeReturn(self, op):
    # no return for constructor, destructor or operator method
    if ( op.isStereotyped("create") or op.isStereotyped("destroy") or op.isStereotyped("Cxx.CastOperator")):
      return ""
      
    # ordinary method
    returnParameter = op.getReturn()
    if (returnParameter is None):
      return "void"
    else:
      if self.forDefinition:
        return GEN.makeCxxSignature(returnParameter)
      else:
        return GEN.makeHxxSignature(returnParameter)
    
  def makeOpName(self, op):
    # method name
    res = ""
    if self.forDefinition:
      res += CXX.makeNamespacing(op)
    else:
      res += CXX.makeCxxName(op)
    return res
    
  def makeParameters(self, op):
    res = ""
    # parameters
    for p in op.getIO():
      if (not act.isNoCode(p)):
        if self.forDefinition:
          res += GEN.makeCxxSignature(p)
        else:
          res += GEN.makeHxxSignature(p)
        res += ", "
        
    return res.rstrip(", ")

  def makeConst(self, op):
    if (CXX.isConst(op)):
      return "const"
    else:
      return ""

  def makeInline(self, op):
    if act.isInline(op):
      return "inline "
    else:
      return ""

  def makeCLIDelegate(self, op):
    if op.isStereotyped("Cxx.CLI.Delegate"):
      return "delegate "
    else:
      return ""

  def makeCLISealed(self, op):
    if op.isFinal():
      return " sealed"
    else:
      return ""

  def makeCLINew(self, op):
    if ObUtils.isTagged(op, "Cxx.CLI.NewOperation"):
      return " new"
    else:
      return ""

  def makeCLIOverride(self, op):
    if ObUtils.isTagged(op, "Cxx.CLI.OverrideOperation"):
      return " override"
    else:
      return ""
            
################################################################################
# Generation code
#
# an operation signature is assembled as follows:
#     "$specifiers $return $name($parameters) $const"
          
      
  def run(self, ctx, el):
    out = ctx.getOutputs()[0]
    # the forDefinition property defines whether we are creating a signature for a method definition or a declaration
    self.forDefinition = ctx.getProperty("forDefinition")
    self.isCLI = el.getOwner().isStereotyped("Cxx.CLI.Class") or el.getOwner().isStereotyped("Cxx.CLI.Interface")
    
    _specifiers = self.makeSpecifiers(ctx, el)
    _return = self.makeReturn(el)
    _name = self.makeOpName(el)
    _parameters = self.makeParameters(el)
    _const = self.makeConst(el)
    _inline = self.makeInline(el)

    signature = _inline + _specifiers + _return + " " + _name + "(" + _parameters + ") " + _const
    signature = signature.rstrip(" ").strip(" ")
    
    if (self.isCLI):
      _delegate = self.makeCLIDelegate(el)
      _sealed = self.makeCLISealed(el)
      
      if (not self.forDefinition):
        _new = self.makeCLINew(el)
        _override = self.makeCLIOverride(el)
      else:
        _new = ""
        _override = ""
      
      signature = _delegate + signature + _sealed + _new + _override
              
    out.print(signature)
