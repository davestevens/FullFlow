#
# Template ClassGen
# Binded variables
#   CXX      facilities for Cxx specific production and navigation
#   GEN      facilities for code production
#   MDL      facilities for model navigation and condition testing
#   ENG      ACT ENG (used to call another template))
#
################################################################################
# Local utilities functions 
#    naming rules:
#       - if the utility function directly prints out the generated code it must be named printXXXXX  
#         where XXXX is expected to summarize the function role
#       - if the utility function return a piece of generated code as a string it must be name makeXXXXXX 
#         where XXXX is expected to summarize the function role
#       - if the utility function is used to get some elements of the model and return a list of model elements (navigation convinience)
#         it must be named modelGetXXXXX where XXXX is expected to summarize the function role
#    other rules:
#       - any utility function takes a model element as first parameter (name it el)
#       - utility function must not define global variables of their own
#
from com.modeliosoft.modelio.cxxdesigner.engine.act import IAct
from com.modeliosoft.modelio.api.model import ObUtils
from com.modeliosoft.modelio.api import *
from com.modeliosoft.modelio.api.model.uml.infrastructure import *
from com.modeliosoft.modelio.api.model.uml.statik import *
import act

class ClassGen (IAct):
  def printBodyAutoIncludes(self, out, el):
    bodyAuto = CXX.getBodyAutoIncludes(el)
    if len(bodyAuto) > 0:
      out.println("//automatic includes (forward declarations, ...)")
      for s in bodyAuto:
        out.printf("#include <%s>\n", [s])
      out.println()
  
  
      
  def printUseIncludes(self, out, el):
    bodyUse = CXX.getBodyUseIncludes(el)
    if len(bodyUse) > 0:
      out.println("//includes for used external code")
      for s in bodyUse:
        out.printf("#include <%s>\n", [s])
      out.println()
  
  
    
  def printIncludeNotes(self, out, el):
    notes = GEN.getModifiableNotes(el, "Cxx.Use.Body")
    if len(notes) > 0:
      for s in notes:
        out.println(s)
      out.println()
  
  
  
  def printBodyTopNotes(self, out, el):
    notes = GEN.getModifiableNotes(el, "Cxx.Body.Top")			
    if len(notes) > 0:
      for s in notes:
        out.println(s)
      out.println()
  
  
  		
  def printBodyBottomNotes(self, out, el):
    notes = GEN.getModifiableNotes(el, "Cxx.Body.Bottom")			
    if len(notes) > 0:
      for s in notes:
        out.println(s)
      out.println()
  
  
  
  def printOpenNamespace(self, out, el):
    for ns in CXX.getNamespacePackages(el):
      out.printf("namespace %s {\n", [CXX.makeCxxName(ns)])
  
  
  
  def printCloseNamespace(self, out, el):
    parentNamespaces = CXX.getNamespacePackages(el)
    parentNamespaces.reverse()
    for ns in parentNamespaces:
      out.printf("} // namespace %s\n", [CXX.makeCxxName(ns)])

    
    
  def makeValidCxxId(self, el):
    id = el.getIdentifier();
    id = id.replace("-", "_");
  
    return id;
  
  
  
  def makeHeaderGuardDefine(self, el):
    return "__" + CXX.makeCxxName(el) + "_" + self.makeValidCxxId(el) + "_H_INCLUDED"
  
  
  def printHeaderTopNotes(self, out, el):
    notes = GEN.getModifiableNotes(el, "Cxx.Header.Top")
    if len(notes) > 0:
      for s in notes:
        out.println(s)
      out.println()  
  
  
  def printHeaderBottomNotes(self, out, el):
    notes = GEN.getModifiableNotes(el, "Cxx.Header.Bottom")
    if len(notes) > 0:
      for s in notes:
        out.println(s)
      out.println()



  def printBodyContent(self, out, el):
    out.println()
    self.printUseIncludes(out, el)
    out.println("//class header file")
    out.printf("#include \"%s\"\n", [CXX.makeHeaderFilename(el)])
    out.println()
    self.printBodyAutoIncludes(out, el)
    self.printIncludeNotes(out, el)
    self.printBodyTopNotes(out, el)
    self.printOpenNamespace(out, el)
    out.println(ENG.evalAct("ClassDefinitionCxx", el))
    self.printCloseNamespace(out, el)
    self.printBodyBottomNotes(out, el)



  ################################################################################
  # Code generation
  #
  def run(self, ctx, el):
    hxx = ctx.getOutputs()[0]
    cxx = ctx.getOutputs()[1]
    
    # cxx file
    if not act.isExternal(el):
      cxx.println(act.makeCopyright(el))
      
      cxx.println("/*")
      cxx.printf(" * File Type: %s body\n", [el.getMetaclassName()])
      cxx.printf(" * Class: %s\n", [el.getName()])
      cxx.println(" */")
      cxx.println()
      
      # content for the elements that were grouped with this class
      for groupedElement in MDL.getGroupedElements (el):
        self.printBodyContent(cxx, groupedElement)
        cxx.println()
      
      # content for the class itself    
      self.printBodyContent(cxx, el)

    # hxx file
    
    hxx.println(act.makeCopyright(el)) 

    hxx.printf("#ifndef %s\n", [self.makeHeaderGuardDefine(el)])
    hxx.printf("#define %s\n", [self.makeHeaderGuardDefine(el)])
    hxx.println()
    hxx.println("/*")
    hxx.printf(" * File Type: %s header\n", [el.getMetaclassName()])
    hxx.printf(" * Class: %s\n", [el.getName()])
    hxx.println(" */")
    hxx.println()
  				
    # content for the elements that were grouped with this class
    for groupedElement in MDL.getGroupedElements (el):
      hxx.println(ENG.evalAct("ClassDeclarationHxx", groupedElement))
      hxx.println(ENG.evalAct("ClassDefinitionHxx", groupedElement))
      hxx.println()
  				
    # Content for this class
    if act.isExternal(el):
      hxx.println(GEN.getExternalContents(el))
    else:
      hxx.println(ENG.evalAct("ClassIncludesHxx", el))
      self.printHeaderTopNotes(hxx, el)
      hxx.println(ENG.evalAct("ForwardDeclsOtherNamespaces", el))
      self.printOpenNamespace(hxx, el)
      hxx.println(ENG.evalAct("ForwardDeclsNamespace", el))
      
      if el.isStereotyped("Cxx.CLI.DelegateContainer"):
        hxx.println(ENG.evalAct("ClassDefinitionHxxCLIDelegateContainer", el))
      else:
        hxx.println(ENG.evalAct("ClassDeclarationHxx", el))
        hxx.println(ENG.evalAct("ClassDefinitionHxx", el))
      
      self.printCloseNamespace(hxx, el)
      self.printHeaderBottomNotes(hxx, el)
  				
    hxx.printf("#endif // %s\n", [self.makeHeaderGuardDefine(el)])
  
