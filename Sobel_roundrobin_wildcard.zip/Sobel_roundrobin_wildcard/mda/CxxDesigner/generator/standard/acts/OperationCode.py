#
# Template OperationCode
# Binded variables
#   CXX      facilities for Cxx specific production and navigation
#   GEN      facilities for code production
#   MDL      facilities for model navigation and condition testing
#   ENG      ACT ENG (used to call another template))
#
################################################################################
# Local utilities functions 
#    naming rules:
#       - if the utility function directly prints out the generated code it must be named printXXXXX  
#         where XXXX is expected to summarize the function role
#       - if the utility function return a piece of generated code as a string it must be name makeXXXXXX 
#         where XXXX is expected to summarize the function role
#       - if the utility function is used to get some elements of the model and return a list of model elements (navigation convinience)
#         it must be named modelGetXXXXX where XXXX is expected to summarize the function role
#    other rules:
#       - any utility function takes a model element as first parameter (name it el)
#       - utility function must not define global variables of their own
#
from com.modeliosoft.modelio.cxxdesigner.engine.act import IAct
from com.modeliosoft.modelio.api import *
from com.modeliosoft.modelio.api.model.uml.infrastructure import *
from com.modeliosoft.modelio.api.model.uml.statik import *
from com.modeliosoft.modelio.api.model import ObUtils
import act

class OperationCode (IAct):
  
  def printCodeNotes(self, out, el):
    for s in GEN.getModifiableNotes(el, "Cxx.Code", "// TODO complete code"):
      out.println(s)
  			
  def printReturnNote(self, out, el):
    returnNotes = GEN.getModifiableNotes(el, "Cxx.Operation.Returned")
    if (len(returnNotes) > 0):
      out.println(returnNotes[0])
  
  def printConstructorInitialisation(self, out, el):
    results = ""
    cls = el.getOwner()
    
    autoInitializers = ""
    #process class attributes
    for att in cls.getPart(IAttribute):
      if (not act.isNoCode(att) and not att.isClass()):
        value = ObUtils.getNoteContent(att, "Cxx.Value")
        if (value is None ):
          value = att.getValue()
        if (value != ""):
          autoInitializers = autoInitializers + att.getName() + "(" + value + "), "
    
    #process class assocs
    for assoc in cls.getPart(IAssociationEnd):
      if (not act.isNoCode(assoc) and not assoc.isClass()) :
        value = ObUtils.getNoteContent(assoc, "Cxx.Value")
        if ( not value is None ):
          autoInitializers = autoInitializers + assoc.getName() + "(" + value + "), "
       
    #user defined initializations in "Cxx.Operation.Constructor.Base" notes
    userInitializers = ""
    for s in GEN.getModifiableNotes(el, "Cxx.Operation.Constructor.Base"):
      userInitializers = userInitializers +  s
    
    # the question is now: do we have any initialization to produce ?
    if (len(autoInitializers) > 0 or len(userInitializers) > 0):
      results = ": "
        
    if (len(autoInitializers) > 0):
      results += autoInitializers.rstrip(", ")
      if (len(userInitializers)>0):
          results += ", \n" + userInitializers
    else:
       if (len(userInitializers) > 0):
          results += "\n" + userInitializers
    out.print(results)

################################################################################
# Generation code
#
  def run(self, ctx, op):
    out = ctx.getOutputs()[0]
    
    # Initialize constructor
    if (CXX.isConstructor(op)):
      self.printConstructorInitialisation(out, op)
    
    # Print code notes
    out.println()
    out.println("{")
    self.printCodeNotes(out, op)
    
    # Print return notes
    if (not op.getReturn() is None or op.isStereotyped("Cxx.CastOperator")):
      self.printReturnNote(out, op)
    
    # End of method
    if act.isInline(op) and (not act.isPureVirtual (op) or not ObUtils.getNoteContent(op, "Cxx.Code") is None):
      out.printf("}; // end %s\n", [op.getName()])
    else:
      out.printf("} // end %s\n", [op.getName()])
