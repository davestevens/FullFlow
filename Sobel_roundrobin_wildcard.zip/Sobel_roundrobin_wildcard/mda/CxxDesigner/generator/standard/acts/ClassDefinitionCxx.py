#
# Template ClassDefinitionCxx
# Binded variables
#   CXX      facilities for Cxx specific production and navigation
#   GEN      facilities for code production
#   MDL      facilities for model navigation and condition testing
#   ENG      ACT ENG (used to call another template))
#
################################################################################
# Local utilities functions 
#    naming rules:
#       - if the utility function directly prints out the generated code it must be named printXXXXX  
#         where XXXX is expected to summarize the function role
#       - if the utility function return a piece of generated code as a string it must be name makeXXXXXX 
#         where XXXX is expected to summarize the function role
#       - if the utility function is used to get some elements of the model and return a list of model elements (navigation convinience)
#         it must be named modelGetXXXXX where XXXX is expected to summarize the function role
#    other rules:
#       - any utility function takes a model element as first parameter (name it el)
#       - utility function must not define global variables of their own
#
from com.modeliosoft.modelio.cxxdesigner.engine.act import IAct
from com.modeliosoft.modelio.api.model import ObUtils
from com.modeliosoft.modelio.api import *
from com.modeliosoft.modelio.api.model.uml.infrastructure import *
from com.modeliosoft.modelio.api.model.uml.statik import *
import act

class ClassDefinitionCxx (IAct):
  
  def printBodyTopNotes(self, out, el):
    for s in GEN.getModifiableNotes(el, "Cxx.Body.Top"):
      out.println(s) 
  
  
  
  
  def printBodyBottomNotes(self, out, el):
    for s in GEN.getModifiableNotes(el, "Cxx.Body.Bottom"):
      out.println(s) 
  
  
  
  
  def printStaticMembersInitialization(self, out, el):
    inits = ""
    for att in el.getPart():
      if (isinstance(att, IAttribute)):
        if (att.isClass() and not act.isNoCode(att) and not att.isStereotyped("Cxx.CLI.AttributeProperty")):
          init = self.makeStaticMemberInit(att)
          declaration = self.makeStaticMemberDeclaration(att)
          inits += declaration + init + ";\n"
      elif (isinstance(att, IAssociationEnd)):
        if (att.isNavigable() and att.isClass() and not act.isNoCode(att) and not att.isStereotyped("Cxx.CLI.AssociationEndProperty")):
          init = self.makeStaticMemberInit(att)
          declaration = self.makeStaticMemberDeclaration(att)
          inits += declaration + init + ";\n"
    # Insert initializations field if necessary 
    if inits != "":
      out.println("//static members initialization")
      out.println(inits)
  
  
  
  
  def makeCxxExpr(self, el):
      # CxxExpr replacement case, the unique known replacement is '$name'
      decl = ObUtils.getTagValues(el, "Cxx.TypeExpr").get(0) + ";"
      name = el.getName()
      return decl.replace("$name", name)
  
  
  
  def makeStaticMemberDeclaration(self, att):
    # standard case
    # declaration syntax is build as:
    #  decl          = $specifiers $decoratedtype $namespacedname$bindings $init;
    #  decoratedtype = $containerpointers $container($type)
    #  type          = $basetype $pointers
    # 
    # example:
    #  static std::vector<int*> C1::att;
    
    # compute declaration
    decoratedtype=GEN.makeCxxSignature(att)
    
    # compute bindings  
    bindings=""    
    if (ObUtils.isTagged(att, "Cxx.Bind")):
      bindings = "<"
      for p in ObUtils.getTagValues(att, "Cxx.Bind"):
        bindings = bindings + p + ", "
      bindings = bindings.rstrip(", ")
      bindings = bindings + ">"
    
    # final assembly
    decl = decoratedtype + " " + bindings
    
    return decl
  
  
  
  def makeStaticMemberInit(self, att):
    init = ObUtils.getNoteContent(att, "Cxx.Value")
    if (not init is None):
      return "(" + init + ")"
    # there was no Note, for attribute use the att.getValue() default value
    if (isinstance(att, IAttribute)):
      init = att.getValue()
      if (len(init) > 0):
        return "(" + init + ")"
    return ""
  
  
  def makeExplicitInstantiationParams(self, el):
    instantiations=""    
    for p in ObUtils.getTagValues(el, "Cxx.ClassTemplate.Instantiate"):
      instantiations = instantiations + p + ", "
    instantiations = instantiations.rstrip(", ")
  
    return instantiations;
  
  

################################################################################
# Generation code
#
  def run(self, ctx, el):
    out = ctx.getOutputs()[0]
    
    # -- inner classes
    for ownedEl in el.getOwnedElement(IClass):
      if (not act.isNoCode(ownedEl)):
        out.println("//inner class methods definitions")
        self.printBodyTopNotes(out, ownedEl)
        out.println(ENG.evalAct("ClassDefinitionCxx", ownedEl))
        self.printBodyBottomNotes(out, ownedEl)
    
    # -- inner interfaces
    for ownedEl in el.getOwnedElement(IInterface):
      if (not  act.isNoCode(ownedEl)):
        out.println("//inner interface methods definitions")
        self.printBodyTopNotes(out, ownedEl)
        out.println(ENG.evalAct("ClassDefinitionCxx", ownedEl))
        self.printBodyBottomNotes(out, ownedEl)
        
    isCLI = el.isStereotyped("Cxx.CLI.Class") or  el.isStereotyped("Cxx.CLI.Interface")
    if (not isCLI):   
      self.printStaticMembersInitialization(out, el)
    
    if ObUtils.isTagged(el, "Cxx.ClassTemplate.Instantiate"):
      out.println("template class " + CXX.makeCxxName(el) + "<" + self.makeExplicitInstantiationParams(el) + ">;")
    
    # -- method definitions
    # for a body file do not generate methods when el is an interface except destructors
    for op in el.getPart(IOperation):
      if (not act.isNoCode(op) and not act.isInline(op) and not op.isStereotyped("Cxx.CLI.Delegate")):
        if (isinstance(el, IInterface)):
          if (op.isStereotyped("destroy")):
            res = ENG.evalAct("OperationGenCxx", op)
            out.println(res)
        else:
          if (not op.isAbstract() or not ObUtils.getNoteContent(op, "Cxx.Code") is None):
            res = ENG.evalAct("OperationGenCxx", op)
            out.println(res)
        
    # out.println(ENG.evalAct("ClassBodyPortsInitialization", el))
